// Charger les notes
async function loadNotes() {
    try {
        const response = await fetch('/api/notes');
        if (!response.ok) {
            throw new Error('Erreur lors du chargement des notes');
        }
        const notes = await response.json();

        const notesList = document.getElementById('notesList');
        notesList.innerHTML = notes.map(note => `
            <div class="note">
                <button class="delete-btn" onclick="deleteNote(${note.id})">×</button>
                <h3>${note.title}</h3>
                <p>${note.content}</p>
                <small>${new Date(note.created_at).toLocaleString()}</small>
            </div>
        `).join('');
    } catch (error) {
        console.error('Erreur lors du chargement des notes:', error);
        const notesList = document.getElementById('notesList');
        notesList.innerHTML = `
            <div class="error">
                Une erreur est survenue lors du chargement des notes.
                <button onclick="loadNotes()">Réessayer</button>
            </div>
        `;
    }
}

// Supprimer une note
async function deleteNote(id) {
    if (!confirm('Voulez-vous vraiment supprimer cette note ?')) {
        return;
    }

    try {
        const response = await fetch(`/api/notes/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Erreur lors de la suppression');
        }

        await loadNotes();
    } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur lors de la suppression de la note');
    }
}

// Gérer l'ajout de note
document.getElementById('noteForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const noteData = Object.fromEntries(formData);

    try {
        const response = await fetch('/api/notes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(noteData)
        });

        if (!response.ok) {
            throw new Error('Erreur lors de l\'ajout');
        }

        await loadNotes();
        this.reset();
    } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur lors de l\'ajout de la note');
    }
});

// Charger les notes au démarrage
loadNotes();