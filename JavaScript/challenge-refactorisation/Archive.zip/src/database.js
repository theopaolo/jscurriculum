const Database = require('better-sqlite3');
const path = require('path');

function initDatabase() {
    const db = new Database(path.join(__dirname, '../database/notes.db'));

    db.exec(`
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            content TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    return db;
}

function addNote(db, title, content) {
    const insertNoteStatement = db.prepare('INSERT INTO notes (title, content) VALUES (?, ?)');
    return insertNoteStatement.run(title, content);
}

function getNotes(db) {
    return db.prepare('SELECT * FROM notes ORDER BY created_at DESC').all();
}

function deleteNote(db, id) {
    const deleteUsersStatement = db.prepare('DELETE FROM notes WHERE id = ?');
    return deleteUsersStatement.run(id);
}

module.exports = { initDatabase, addNote, getNotes, deleteNote };