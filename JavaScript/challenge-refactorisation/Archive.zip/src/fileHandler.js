const fs = require('fs');
const path = require('path');

const MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript'
};

function serveStaticFile(req, res, pathname) {
    // Rediriger vers index.html par défaut
    if (pathname === '/') {
        pathname = '/index.html';
    }

    // Chemin vers le fichier demandé
    const filePath = path.join(__dirname, '../public', pathname);

    // Lire et servir le fichier
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('File not found');
            return;
        }

        const ext = path.extname(filePath);
        res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'text/plain' });
        res.end(data);
    });
}

module.exports = { serveStaticFile };