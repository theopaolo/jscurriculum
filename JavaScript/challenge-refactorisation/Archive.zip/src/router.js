const { serveStaticFile } = require('./fileHandler');
const { addNote, getNotes, deleteNote } = require('./database');

function handleRequest(req, res, db) {
    const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = parsedUrl.pathname;

    // API pour les notes
    if (pathname.startsWith('/api/notes')) {
        // GET - Récupérer toutes les notes
        if (pathname === '/api/notes' && req.method === 'GET') {
            const notes = getNotes(db);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(notes));
            return;
        }

        // POST - Ajouter une nouvelle note
        if (pathname === '/api/notes' && req.method === 'POST') {
            let body = '';
            req.on('data', chunk => body += chunk.toString());
            req.on('end', () => {
                try {
                    const { title, content } = JSON.parse(body);
                    addNote(db, title, content);
                    res.writeHead(201, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true }));
                } catch (error) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'Invalid data' }));
                }
            });
            return;
        }

        // DELETE - Supprimer une note
        if (pathname.startsWith('/api/notes/') && req.method === 'DELETE') {
            const id = parseInt(pathname.split('/').pop());
            if (isNaN(id)) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Invalid ID' }));
                return;
            }
            try {
                deleteNote(db, id);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            } catch (error) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Failed to delete note' }));
            }
            return;
        }
    }

    // Servir les fichiers statiques
    serveStaticFile(req, res, pathname);
}

module.exports = { handleRequest };