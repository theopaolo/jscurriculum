const http = require('http');
const router = require('./router');
const { initDatabase } = require('./database');

const PORT = 3000;
const db = initDatabase();

const server = http.createServer((req, res) => {
    router.handleRequest(req, res, db);
});

server.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
});