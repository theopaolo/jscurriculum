class NotesAPI {
    static async getAllNotes() {
        const response = await fetch('/api/notes');
        if (!response.ok) throw new Error('Erreur lors du chargement des notes');
        return response.json();
    }

    static async createNote(noteData) {
        const response = await fetch('/api/notes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(noteData)
        });
        if (!response.ok) throw new Error('Erreur lors de l\'ajout');
        return response.json();
    }

    static async deleteNote(id) {
        const response = await fetch(`/api/notes/${id}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('Erreur lors de la suppression');
    }
}

class NotesUI {
    constructor() {
        this.notesList = document.getElementById('notesList');
        this.noteForm = document.getElementById('noteForm');
        this.bindEvents();
        this.loadNotes();
    }

    bindEvents() {
        this.noteForm.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    async loadNotes() {
        try {
            const notes = await NotesAPI.getAllNotes();
            this.displayNotes(notes);
        } catch (error) {
            this.showError('Erreur lors du chargement des notes', error);
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const noteData = Object.fromEntries(formData);

        try {
            await NotesAPI.createNote(noteData);
            e.target.reset();
            await this.loadNotes();
        } catch (error) {
            this.showError('Erreur lors de l\'ajout de la note', error);
        }
    }

    async deleteNote(id) {
        if (!confirm('Voulez-vous vraiment supprimer cette note ?')) return;

        try {
            await NotesAPI.deleteNote(id);
            await this.loadNotes();
        } catch (error) {
            this.showError('Erreur lors de la suppression de la note', error);
        }
    }

    displayNotes(notes) {
        this.notesList.innerHTML = notes.map(note => this.createNoteHTML(note)).join('');
    }

    createNoteHTML(note) {
        return `
            <div class="note">
                <button class="delete-btn" onclick="notesUI.deleteNote(${note.id})">×</button>
                <h3>${this.escapeHTML(note.title)}</h3>
                <p>${this.escapeHTML(note.content)}</p>
                <small>${new Date(note.created_at).toLocaleString()}</small>
            </div>
        `;
    }

    escapeHTML(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    showError(message, error) {
        console.error(error);
        this.notesList.innerHTML = `
            <div class="error">
                ${message}
                <button onclick="notesUI.loadNotes()">Réessayer</button>
            </div>
        `;
    }
}

// Initialisation
const notesUI = new NotesUI();