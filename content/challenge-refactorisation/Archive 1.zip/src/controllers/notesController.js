const Note = require('../models/Note');

exports.getAllNotes = async (req, res, next) => {
    try {
        const notes = Note.getAll();
        res.json(notes);
    } catch (error) {
        next(error);
    }
};

exports.getNote = async (req, res, next) => {
    try {
        const note = Note.getById(req.params.id);
        if (!note) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.json(note);
    } catch (error) {
        next(error);
    }
};

exports.createNote = async (req, res, next) => {
    try {
        const note = Note.create(req.body);
        res.status(201).json(note);
    } catch (error) {
        next(error);
    }
};

exports.updateNote = async (req, res, next) => {
    try {
        const result = Note.update(req.params.id, req.body);
        if (result.changes === 0) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.json({ message: 'Note updated successfully' });
    } catch (error) {
        next(error);
    }
};

exports.deleteNote = async (req, res, next) => {
    try {
        const result = Note.delete(req.params.id);
        if (result.changes === 0) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.json({ message: 'Note deleted successfully' });
    } catch (error) {
        next(error);
    }
};