const db = require('../config/database');

class Note {
    static getAll() {
        const stmt = db.prepare('SELECT * FROM notes ORDER BY created_at DESC');
        return stmt.all();
    }

    static getById(id) {
        const stmt = db.prepare('SELECT * FROM notes WHERE id = ?');
        return stmt.get(id);
    }

    static create(noteData) {
        const { title, content } = noteData;
        const stmt = db.prepare('INSERT INTO notes (title, content) VALUES (?, ?)');
        const result = stmt.run(title, content);
        return { id: result.lastInsertRowid, title, content };
    }

    static update(id, noteData) {
        const { title, content } = noteData;
        const stmt = db.prepare('UPDATE notes SET title = ?, content = ? WHERE id = ?');
        return stmt.run(title, content, id);
    }

    static delete(id) {
        const stmt = db.prepare('DELETE FROM notes WHERE id = ?');
        return stmt.run(id);
    }
}

module.exports = Note;